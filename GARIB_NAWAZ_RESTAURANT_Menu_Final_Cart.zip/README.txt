GARIB NAWAZ RESTAURANT — Digital Menu
=========================================

This version adds a food-photo visual to every menu card. Photos are representative
food images matched by category; they are not claimed to be photographs taken at
GARIB NAWAZ RESTAURANT. Some images are loaded from Wikimedia Commons and require
internet access. User-supplied menu images remain bundled locally as fallbacks.

The menu itself, search, categories, prices, phone, WhatsApp and Location buttons
are included in index.html.
